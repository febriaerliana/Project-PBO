package models;

/**
 *
 * @author amir
 */
public class Tips {
    
    int id ;
    String judul, konten;
    
    public void setId(int id) {
        this.id = id;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public void setKonten(String konten) {
        this.konten = konten;
    }

    public int getId() {
        return id;
    }

    public String getJudul() {
        return judul;
    }
    
    public String getKonten() {
        return konten;
    }

    public Tips(int id, String judul, String konten) {
        this.id = id;
        this.judul = judul;
        this.konten = konten;
    }

}
package models;

public class AllEvents {
    String eventid, judul, konten, link;

    public AllEvents(String eventid, String judul, String konten, String link) {
        this.eventid = eventid;
        this.judul = judul;
        this.konten = konten;
        this.link = link;
    }

    public String getEventid() {
        return eventid;
    }

    public void setEventid(String eventid) {
        this.eventid = eventid;
    }

    public String getJudul() {
        return judul;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public String getKonten() {
        return konten;
    }

    public void setKonten(String konten) {
        this.konten = konten;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }
    
    
}

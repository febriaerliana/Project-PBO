package models;

public class AllNews {
    String newsid, judul, konten;

    public AllNews(String newsid, String judul, String konten) {
        this.newsid = newsid;
        this.judul = judul;
        this.konten = konten;
    }

    public String getNewsid() {
        return newsid;
    }

    public void setNewsid(String newsid) {
        this.newsid = newsid;
    }

    public String getJudul() {
        return judul;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public String getKonten() {
        return konten;
    }

    public void setKonten(String konten) {
        this.konten = konten;
    }
    
}

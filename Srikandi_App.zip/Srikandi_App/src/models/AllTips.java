package models;

public class AllTips {
    String tipsid, judul, konten;

    public AllTips(String tipsid, String judul, String konten) {
        this.tipsid = tipsid;
        this.judul = judul;
        this.konten = konten;
    }

    public String getTipsid() {
        return tipsid;
    }

    public void setTipsid(String tipsid) {
        this.tipsid = tipsid;
    }

    public String getJudul() {
        return judul;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public String getKonten() {
        return konten;
    }

    public void setKonten(String konten) {
        this.konten = konten;
    }
    
    
}

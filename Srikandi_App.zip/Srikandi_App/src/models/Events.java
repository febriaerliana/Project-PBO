package models;

/**
 *
 * @author amir
 */
public class Events {
    
    int id ;
    String judul, konten, link;
    
    public void setId(int id) {
        this.id = id;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public void setKonten(String konten) {
        this.konten = konten;
    }

    public void setLink(String link) {
        this.link = link;
    }
    
    public int getId() {
        return id;
    }

    public String getJudul() {
        return judul;
    }
    
    public String getKonten() {
        return konten;
    }
    
    public String getLink() {
        return link;
    }

    public Events(int id, String judul, String konten, String link) {
        this.id = id;
        this.judul = judul;
        this.konten = konten;
        this.link = link;
    }

}
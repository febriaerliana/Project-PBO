 package utils;
 
 import java.sql.Connection;
 import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import models.Events;
import models.News;
import models.Tips;
 
 public class ConnectionUtil
 {
   Connection conn = null;
   
   public static Connection conDB() {
     try {
       Class.forName("com.mysql.jdbc.Driver");
       Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/adplb", "root", "");
       return conn;
     }
     catch (ClassNotFoundException|java.sql.SQLException ex) {
       System.err.println("ConnectionUtil : " + ex.getMessage()); }
     return null;
   }
   
   public static ObservableList<Events> getDataevents(){
        Connection conn = conDB();
        ObservableList<Events> list = FXCollections.observableArrayList();
        try {
            PreparedStatement ps = conn.prepareStatement("select * from eventss");
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()){   
                list.add(new Events(Integer.parseInt(rs.getString("eventid")), rs.getString("judul"), rs.getString("konten"), rs.getString("link")));               
            }
        } catch (Exception e) {
        }
        return list;
    }
   
   public static ObservableList<News> getDatanews(){
        Connection conn = conDB();
        ObservableList<News> list = FXCollections.observableArrayList();
        try {
            PreparedStatement ps = conn.prepareStatement("select * from news");
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()){   
                list.add(new News(Integer.parseInt(rs.getString("newsid")), rs.getString("judul"), rs.getString("konten")));               
            }
        } catch (Exception e) {
        }
        return list;
    }
   
   public static ObservableList<Tips> getDatatips(){
        Connection conn = conDB();
        ObservableList<Tips> list = FXCollections.observableArrayList();
        try {
            PreparedStatement ps = conn.prepareStatement("select * from tips");
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()){   
                list.add(new Tips(Integer.parseInt(rs.getString("tipsid")), rs.getString("judul"), rs.getString("konten")));               
            }
        } catch (Exception e) {
        }
        return list;
    }
   
 }
